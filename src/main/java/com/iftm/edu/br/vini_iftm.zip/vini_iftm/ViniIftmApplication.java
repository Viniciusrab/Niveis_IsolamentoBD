package com.iftm.edu.br.vini_iftm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViniIftmApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViniIftmApplication.class, args);
	}

}
